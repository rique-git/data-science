target_columns = ['latitude', 'longitude']
predicted_columns = ['latitude_predicted', 'longitude_predicted']